from discord.ext import commands
import discord
from collections import defaultdict
import asyncio

class AntiSpam(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.message_history = defaultdict(list)
        self.warning_count = defaultdict(int)
        self.cleanup_task = bot.loop.create_task(self.cleanup_message_history())
        self.coowner_id = None  # Will be set when needed

    def cog_unload(self):
        self.cleanup_task.cancel()

    async def cleanup_message_history(self):
        while True:
            await asyncio.sleep(60)  # Clean up every minute
            for user_id in list(self.message_history.keys()):
                # Remove messages older than 5 seconds
                self.message_history[user_id] = [
                    msg for msg in self.message_history[user_id]
                    if (discord.utils.utcnow() - msg.created_at).seconds <= 5
                ]

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        # Try to find oliebolle if we haven't yet
        if self.coowner_id is None:
            for guild in self.bot.guilds:
                member = discord.utils.get(guild.members, name='oliebolle')
                if member:
                    self.coowner_id = member.id
                    break

        user_id = message.author.id
        self.message_history[user_id].append(message)

        # Check for duplicate messages in the last 5 seconds
        recent_messages = [
            msg for msg in self.message_history[user_id]
            if (discord.utils.utcnow() - msg.created_at).seconds <= 5
        ]

        # Check for spam conditions
        if len(recent_messages) >= 5:  # More than 5 messages in 5 seconds
            await self.handle_spam(message, "message frequency")
            return

        # Check for duplicate content
        content_count = sum(1 for msg in recent_messages if msg.content == message.content)
        if content_count >= 3:  # Same message 3 times in 5 seconds
            await self.handle_spam(message, "duplicate messages")
            return

    async def handle_spam(self, message, spam_type):
        user_id = message.author.id
        self.warning_count[user_id] += 1

        # Delete spam messages except the first one
        first_message = None
        for msg in sorted(self.message_history[user_id], key=lambda x: x.created_at):
            if first_message is None:
                first_message = msg
                continue
            try:
                await msg.delete()
            except discord.errors.NotFound:
                pass

        # Clear the message history for this user but keep the first message
        self.message_history[user_id] = [first_message] if first_message else []

        # Send warning (auto-deletes after 5 seconds)
        warning_msg = f"⚠️ {message.author.mention} Please stop spamming ({spam_type})! Warning {self.warning_count[user_id]}/3"
        await message.channel.send(warning_msg, delete_after=5)

        # Prepare notification embed
        embed = discord.Embed(
            title="🚨 Spam Alert",
            description=f"Spam detected in server: **{message.guild.name}**",
            color=discord.Color.red()
        )
        embed.add_field(
            name="User Information",
            value=f"**Name:** {message.author.name}\n"
                  f"**ID:** {message.author.id}\n"
                  f"**Warning Count:** {self.warning_count[user_id]}/3",
            inline=False
        )
        embed.add_field(
            name="Spam Details",
            value=f"**Type:** {spam_type}\n"
                  f"**Channel:** {message.channel.mention}\n"
                  f"**First Message:** {first_message.content if first_message else 'Not available'}",
            inline=False
        )
        embed.set_footer(text=f"Time: {discord.utils.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}")

        # Send notification to server owner
        if message.guild.owner:
            try:
                await message.guild.owner.send(embed=embed)
            except discord.Forbidden:
                pass  # Owner has DMs disabled

        # Send notification to bot owner and co-owner
        owner = await self.bot.fetch_user(self.bot.owner_id)
        if owner:
            await owner.send(embed=embed)

        if self.coowner_id:
            coowner = await self.bot.fetch_user(self.coowner_id)
            if coowner:
                await coowner.send(embed=embed)

        # Handle mute after 3 warnings
        if self.warning_count[user_id] >= 3:
            # Create muted role if it doesn't exist
            muted_role = discord.utils.get(message.guild.roles, name="Muted")
            if not muted_role:
                try:
                    muted_role = await message.guild.create_role(
                        name="Muted",
                        reason="Anti-spam system: Muted role"
                    )
                    # Set up permissions for the muted role
                    for channel in message.guild.channels:
                        await channel.set_permissions(muted_role, send_messages=False)
                except discord.Forbidden:
                    await message.channel.send("⚠️ Could not create Muted role. Please check bot permissions.")
                    return

            try:
                # Mute the user
                await message.author.add_roles(muted_role, reason=f"Anti-spam: Received {self.warning_count[user_id]} warnings")
                mute_msg = f"🔇 {message.author.mention} has been muted for spam (3 warnings received)."
                await message.channel.send(mute_msg, delete_after=5)

                # Reset warning count
                self.warning_count[user_id] = 0

                # Notify owner and co-owner about the mute
                mute_embed = discord.Embed(
                    title="🔇 User Muted",
                    description=f"**{message.author.name}** has been muted for spam.",
                    color=discord.Color.dark_red()
                )
                mute_embed.add_field(name="Server", value=message.guild.name, inline=False)
                mute_embed.add_field(name="Reason", value="Received 3 spam warnings", inline=False)

                # Send mute notification to server owner
                if message.guild.owner:
                    try:
                        await message.guild.owner.send(embed=mute_embed)
                    except discord.Forbidden:
                        pass  # Owner has DMs disabled

                if owner:
                    await owner.send(embed=mute_embed)
                if self.coowner_id and coowner:
                    await coowner.send(embed=mute_embed)

            except discord.Forbidden:
                await message.channel.send("⚠️ Could not mute user. Please check bot permissions.")

async def setup(bot):
    await bot.add_cog(AntiSpam(bot))