from discord.ext import commands
import discord
from utils.storage import currency_storage, streak_storage, last_daily_storage
from utils.checks import is_owner
import asyncio
from datetime import datetime, timedelta

class Economy(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Load any existing data
        self._ensure_storage_loaded()

    def _ensure_storage_loaded(self):
        """Ensure storage is properly initialized"""
        try:
            currency_storage.load()
            streak_storage.load()
            last_daily_storage.load()
        except Exception as e:
            print(f"Error loading storage: {e}")

    def _save_last_daily(self, user_id: str, time: datetime):
        """Save last daily claim time"""
        last_daily_storage.set(user_id, time.isoformat())

    def _get_last_daily(self, user_id: str) -> datetime:
        """Get last daily claim time"""
        last_claim = last_daily_storage.get(user_id)
        return datetime.fromisoformat(last_claim) if last_claim else None

    @commands.command(name='donate')
    @commands.cooldown(1, 30, commands.BucketType.user)  # 30 second cooldown
    async def donate(self, ctx, recipient: discord.Member, amount: int):
        """Donate FrostedCash to another user (Max 250k)"""
        if amount <= 0:
            embed = discord.Embed(
                title="❌ Invalid Amount",
                description="Donation amount must be positive!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        if amount > 250000:
            embed = discord.Embed(
                title="❌ Exceeds Limit",
                description="Maximum donation amount is 250,000 FrostedCash!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        if recipient.bot:
            embed = discord.Embed(
                title="❌ Invalid Recipient",
                description="You cannot donate to bots!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        if recipient.id == ctx.author.id:
            embed = discord.Embed(
                title="❌ Invalid Recipient",
                description="You cannot donate to yourself!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        sender_id = str(ctx.author.id)
        recipient_id = str(recipient.id)
        sender_balance = currency_storage.get(sender_id, 0)

        if sender_balance < amount:
            embed = discord.Embed(
                title="❌ Insufficient Funds",
                description="You don't have enough FrostedCash to make this donation!",
                color=discord.Color.red()
            )
            embed.add_field(name="Your Balance", value=f"**{sender_balance:,} FrostedCash**", inline=True)
            embed.add_field(name="Required", value=f"**{amount:,} FrostedCash**", inline=True)
            await ctx.send(embed=embed)
            return

        # Process the donation
        if recipient_id not in currency_storage:
            currency_storage[recipient_id] = 0

        currency_storage[sender_id] -= amount
        currency_storage[recipient_id] += amount

        embed = discord.Embed(
            title="💝 Donation Sent!",
            description=f"**{ctx.author.name}** has donated to **{recipient.name}**!",
            color=discord.Color.purple()
        )
        embed.add_field(name="Amount", value=f"**{amount:,} FrostedCash**", inline=True)
        embed.add_field(name="Your New Balance", value=f"**{currency_storage[sender_id]:,} FrostedCash**", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name='daily')
    @commands.cooldown(1, 86400, commands.BucketType.user)
    async def daily(self, ctx):
        """Claim daily reward (1000 FrostedCash + streak bonus)"""
        user_id = str(ctx.author.id)
        base_reward = 1000

        # Get current values
        current_balance = currency_storage.get(user_id, 0)
        current_streak = streak_storage.get(user_id, 0)
        last_claim = self._get_last_daily(user_id)

        now = datetime.utcnow()

        # Check if this is a consecutive day claim
        if last_claim is not None:
            time_diff = now - last_claim
            if time_diff > timedelta(hours=48):  # If more than 48 hours passed, reset streak
                streak_storage.set(user_id, 0)
                current_streak = 0
            elif time_diff > timedelta(hours=24):  # If between 24-48 hours, increment streak
                current_streak += 1
                streak_storage.set(user_id, current_streak)

        # Update last claim time
        self._save_last_daily(user_id, now)

        # Calculate reward with streak bonus
        bonus = int(base_reward * (current_streak * 0.05))  # 5% bonus per streak day
        total_reward = base_reward + bonus

        # Update balance
        new_balance = current_balance + total_reward
        currency_storage.set(user_id, new_balance)

        # Create embed with streak information
        embed = discord.Embed(
            title="💰 Daily Reward Claimed!",
            description=f"**{ctx.author.name}** received their daily reward!",
            color=discord.Color.green()
        )

        # Add streak information
        if current_streak > 0:
            embed.add_field(
                name="🔥 Streak Bonus",
                value=(
                    f"**Day {current_streak} Streak!**\n"
                    f"**Base: {base_reward:,} FC**\n"
                    f"**Bonus: +{bonus:,} FC ({current_streak * 5}%)**"
                ),
                inline=True
            )

        embed.add_field(
            name="💎 Total Reward",
            value=f"**{total_reward:,} FrostedCash**",
            inline=True
        )
        embed.add_field(
            name="💳 New Balance",
            value=f"**{new_balance:,} FrostedCash**",
            inline=True
        )

        if current_streak > 0:
            embed.set_footer(text=f"┗━━━━━━ Keep the streak going! Next claim in 24h ━━━━━━┛")
        else:
            embed.set_footer(text=f"┗━━━━━━ Start a streak! Claim daily for bonus rewards ━━━━━━┛")

        await ctx.send(embed=embed)

    @commands.command(name='balance')
    async def balance(self, ctx):
        """Check your current balance"""
        user_id = str(ctx.author.id)
        balance = currency_storage.get(user_id, 0)
        embed = discord.Embed(
            title="💳 Balance Check",
            description=f"**{ctx.author.name}'s** current balance",
            color=discord.Color.blue()
        )
        embed.add_field(name="Balance", value=f"**{balance:,} FrostedCash**", inline=False)
        await ctx.send(embed=embed)

    @commands.command(name='give')
    @is_owner()
    async def give(self, ctx, user: discord.Member, amount: int):
        """Give FrostedCash to a user (Owner only)"""
        if amount <= 0:
            embed = discord.Embed(
                title="❌ Error",
                description="Amount must be positive!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        user_id = str(user.id)
        current_balance = currency_storage.get(user_id, 0)
        new_balance = current_balance + amount
        currency_storage.set(user_id, new_balance)

        embed = discord.Embed(
            title="🎁 Gift Sent!",
            description=f"**{ctx.author.name}** sent a gift to **{user.name}**!",
            color=discord.Color.purple()
        )
        embed.add_field(name="Amount", value=f"**{amount:,} FrostedCash**", inline=True)
        embed.add_field(name="New Balance", value=f"**{new_balance:,} FrostedCash**", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name='grab')
    @is_owner()
    async def grab(self, ctx, user_id: str, amount: int):
        """Grab FrostedCash from a user (Owner only)"""
        if amount <= 0:
            embed = discord.Embed(
                title="❌ Error",
                description="Amount must be positive!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        target_balance = currency_storage.get(user_id, 0)
        if target_balance < amount:
            embed = discord.Embed(
                title="❌ Error",
                description="User doesn't have enough FrostedCash!",
                color=discord.Color.red()
            )
            embed.add_field(name="User Balance", value=f"**{target_balance:,} FrostedCash**", inline=True)
            await ctx.send(embed=embed)
            return

        # Update balances
        new_target_balance = target_balance - amount
        currency_storage.set(user_id, new_target_balance)

        embed = discord.Embed(
            title="💰 Cash Grabbed!",
            description=f"**{ctx.author.name}** grabbed FrostedCash from user ID: **{user_id}**!",
            color=discord.Color.red()
        )
        embed.add_field(name="Amount Grabbed", value=f"**{amount:,} FrostedCash**", inline=True)
        embed.add_field(name="User's New Balance", value=f"**{new_target_balance:,} FrostedCash**", inline=True)
        await ctx.send(embed=embed)

    @commands.command(name='leaderboard')
    async def leaderboard(self, ctx):
        """Show top 100 richest users"""
        # Get all entries and sort them
        sorted_users = sorted(
            [(k, v) for k, v in currency_storage.data.items()],
            key=lambda x: x[1],
            reverse=True
        )[:100]

        if not sorted_users:
            embed = discord.Embed(
                title="🏆 Leaderboard",
                description="No users found in the leaderboard!",
                color=discord.Color.gold()
            )
            await ctx.send(embed=embed)
            return

        embed = discord.Embed(
            title="🏆 Richest Users",
            description="Top players ranked by FrostedCash",
            color=discord.Color.gold()
        )

        for index, (user_id, balance) in enumerate(sorted_users[:10], 1):
            try:
                user = await self.bot.fetch_user(int(user_id))
                username = user.name if user else f"User {user_id}"
            except:
                username = f"User {user_id}"

            medal = "🥇" if index == 1 else "🥈" if index == 2 else "🥉" if index == 3 else "👑"
            embed.add_field(
                name=f"{medal} #{index} {username}",
                value=f"**{balance:,} FrostedCash**",
                inline=False
            )

        await ctx.send(embed=embed)

    @commands.command(name='commands')
    async def commands_list(self, ctx):
        """Shows all available commands"""
        embed = discord.Embed(
            title="┏━━━━━━━━ 🤖 FrosterLand Bot ━━━━━━━━┓",
            description=(
                "```\n"
                "**Welcome to FrosterLand! Your gaming companion.**\n"
                "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                "```"
            ),
            color=discord.Color.gold()
        )

        # Currency Commands
        embed.add_field(
            name="┏━━━━━━ 💰 Currency Commands ━━━━━━┓",
            value=(
                "```\n"
                "• **&daily  - Claim 1000 FrostedCash (24h cooldown)**\n"
                "• **&balance - Check your current balance**\n"
                "• **&donate [user] [amount] - Send up to 250k FC**\n"
                "  **⮡ 30-second cooldown between donations**\n"
                "  **⮡ Maximum donation: 250,000 FrostedCash**\n"
                "• **&leaderboard - View the richest users**\n"
                "```"
            ),
            inline=False
        )

        # Gambling Commands
        embed.add_field(
            name="┏━━━━━━ 🎲 Gambling Commands ━━━━━━┓",
            value=(
                "```\n"
                "• **&HoT [heads/tails] [amount] - Heads or Tails**\n"
                "• **&luck [rock/paper/scissors] [amount] - RPS Game**\n"
                "  **⮡ Use 'all' to bet your entire balance**\n"
                "  **⮡ Double your bet on win!**\n"
                "  **⮡ 3-second countdown animation**\n"
                "  **⮡ 7-second cooldown between bets**\n"
                "```"
            ),
            inline=False
        )

        # Fun Commands
        embed.add_field(
            name="┏━━━━━━ 😄 Fun Commands ━━━━━━┓",
            value=(
                "```\n"
                "• **&coldjoke - Get a random cold joke!**\n"
                "```"
            ),
            inline=False
        )

        # Owner Commands
        if await self.bot.is_owner(ctx.author):
            embed.add_field(
                name="┏━━━━━━ 👑 Owner Commands ━━━━━━┓",
                value="```\n• **&give [user] [amount] - Give FrostedCash to a user**\n• **&grab [user_id] [amount] - Grab FrostedCash from a user**\n```",
                inline=False
            )

        embed.set_footer(text="┗━━━━━━ Use & before each command • Example: &daily ━━━━━━┛")
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Economy(bot))