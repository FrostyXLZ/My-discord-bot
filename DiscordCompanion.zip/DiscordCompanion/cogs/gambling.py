from discord.ext import commands
import random
from utils.storage import currency_storage
import discord
import asyncio

class Gambling(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def _update_balance(self, user_id: str, amount: int):
        """Update user balance and save to storage"""
        current_balance = currency_storage.get(user_id, 0)
        new_balance = current_balance + amount
        currency_storage.set(user_id, new_balance)
        return new_balance

    @commands.command(name='HoT')
    @commands.cooldown(1, 7, commands.BucketType.user)  # Changed to 7 seconds cooldown
    async def heads_or_tails(self, ctx, choice: str, bet: str):
        """Play Heads or Tails with double or lose mechanic (80% chance to lose)"""
        choice = choice.lower()
        if choice not in ['heads', 'tails']:
            embed = discord.Embed(
                title="❌ Invalid Choice",
                description="Please choose either '**heads**' or '**tails**'!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        # Handle bet amount
        user_id = str(ctx.author.id)
        current_balance = currency_storage.get(user_id, 0)

        if bet.lower() == 'all':
            bet_amount = current_balance
        else:
            try:
                bet_amount = int(bet)
            except ValueError:
                embed = discord.Embed(
                    title="❌ Invalid Bet",
                    description="Please use a number or 'all' for your bet!",
                    color=discord.Color.red()
                )
                await ctx.send(embed=embed)
                return

        if bet_amount <= 0:
            embed = discord.Embed(
                title="❌ Invalid Bet",
                description="Bet amount must be positive!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        if current_balance < bet_amount:
            embed = discord.Embed(
                title="❌ Insufficient Funds",
                description="You don't have enough FrostedCash for this bet!",
                color=discord.Color.red()
            )
            embed.add_field(name="Your Balance", value=f"**{current_balance:,} FrostedCash**", inline=True)
            embed.add_field(name="Required", value=f"**{bet_amount:,} FrostedCash**", inline=True)
            await ctx.send(embed=embed)
            return

        # Start the countdown
        countdown_embed = discord.Embed(
            title="🎲 Flipping the Coin...",
            description="The coin is being tossed into the air!",
            color=discord.Color.gold()
        )
        countdown_msg = await ctx.send(embed=countdown_embed)

        # 3-second countdown animation
        for i in range(3, 0, -1):
            countdown_embed.description = f"Revealing in **{i}**..."
            await countdown_msg.edit(embed=countdown_embed)
            await asyncio.sleep(1)

        # 80% chance to lose
        result = 'tails' if choice == 'heads' else 'heads'  # Default to losing result
        if random.random() < 0.2:  # 20% chance to win
            result = choice

        # Delete countdown message
        await countdown_msg.delete()

        # Show result
        embed = discord.Embed(
            title="🎲 Heads or Tails - High Risk Game!",
            description=f"The coin spins through the air...\n\n**RESULT: {result.upper()}!**",
            color=discord.Color.gold()
        )
        embed.add_field(name="Your Choice", value=f"**{choice.upper()}**", inline=True)
        embed.add_field(name="Bet Amount", value=f"**{bet_amount:,} FrostedCash**", inline=True)

        if result == choice:
            # Win - double the bet
            new_balance = self._update_balance(user_id, bet_amount)
            embed.color = discord.Color.green()
            embed.add_field(name="Result", value=f"🎉 **WINNER!** +{bet_amount:,} FrostedCash", inline=False)
            embed.add_field(name="Odds", value="20% chance to win - You beat the odds! 🍀", inline=False)
        else:
            # Lose - lose the bet
            new_balance = self._update_balance(user_id, -bet_amount)
            embed.color = discord.Color.red()
            embed.add_field(name="Result", value=f"💔 **LOSS!** -{bet_amount:,} FrostedCash", inline=False)
            embed.add_field(name="Odds", value="80% chance to lose - House always wins! 🎲", inline=False)

        embed.add_field(name="New Balance", value=f"**{new_balance:,} FrostedCash**", inline=False)
        await ctx.send(embed=embed)

    @commands.command(name='luck')
    @commands.cooldown(1, 7, commands.BucketType.user)  # 7 seconds cooldown
    async def rock_paper_scissors(self, ctx, choice: str, bet: str):
        """Play Rock Paper Scissors with double or lose mechanic (80% chance to lose)"""
        choice = choice.lower()
        if choice not in ['rock', 'paper', 'scissors']:
            embed = discord.Embed(
                title="❌ Invalid Choice",
                description="Please choose '**rock**', '**paper**', or '**scissors**'!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        # Handle bet amount
        user_id = str(ctx.author.id)
        current_balance = currency_storage.get(user_id, 0)

        if bet.lower() == 'all':
            bet_amount = current_balance
        else:
            try:
                bet_amount = int(bet)
            except ValueError:
                embed = discord.Embed(
                    title="❌ Invalid Bet",
                    description="Please use a number or 'all' for your bet!",
                    color=discord.Color.red()
                )
                await ctx.send(embed=embed)
                return

        if bet_amount <= 0:
            embed = discord.Embed(
                title="❌ Invalid Bet",
                description="Bet amount must be positive!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        if current_balance < bet_amount:
            embed = discord.Embed(
                title="❌ Insufficient Funds",
                description="You don't have enough FrostedCash for this bet!",
                color=discord.Color.red()
            )
            embed.add_field(name="Your Balance", value=f"**{current_balance:,} FrostedCash**", inline=True)
            embed.add_field(name="Required", value=f"**{bet_amount:,} FrostedCash**", inline=True)
            await ctx.send(embed=embed)
            return

        # Start the countdown
        countdown_embed = discord.Embed(
            title="🎮 Rock, Paper, Scissors...",
            description="The AI is making its choice...",
            color=discord.Color.gold()
        )
        countdown_msg = await ctx.send(embed=countdown_embed)

        # 3-second countdown animation
        for i in range(3, 0, -1):
            countdown_embed.description = f"Revealing in **{i}**..."
            await countdown_msg.edit(embed=countdown_embed)
            await asyncio.sleep(1)

        # 80% chance to lose
        choices = {
            'rock': {'beats': 'scissors', 'emoji': '🪨'},
            'paper': {'beats': 'rock', 'emoji': '📄'},
            'scissors': {'beats': 'paper', 'emoji': '✂️'}
        }

        if random.random() < 0.2:  # 20% chance to win
            # Choose a losing move against player
            ai_choice = [k for k, v in choices.items() if v['beats'] == choice][0]
        else:
            # Choose a winning move against player
            ai_choice = choices[choice]['beats']

        # Delete countdown message
        await countdown_msg.delete()

        # Determine the winner
        player_wins = choices[choice]['beats'] == ai_choice

        # Show result
        embed = discord.Embed(
            title="🎮 Rock Paper Scissors - High Risk Game!",
            description=(
                f"You chose **{choice.upper()}** {choices[choice]['emoji']}\n"
                f"AI chose **{ai_choice.upper()}** {choices[ai_choice]['emoji']}"
            ),
            color=discord.Color.gold()
        )
        embed.add_field(name="Your Bet", value=f"**{bet_amount:,} FrostedCash**", inline=True)

        if player_wins:
            # Win - double the bet
            new_balance = self._update_balance(user_id, bet_amount)
            embed.color = discord.Color.green()
            embed.add_field(name="Result", value=f"🎉 **WINNER!** +{bet_amount:,} FrostedCash", inline=False)
            embed.add_field(name="Odds", value="20% chance to win - You beat the odds! 🍀", inline=False)
        else:
            # Lose - lose the bet
            new_balance = self._update_balance(user_id, -bet_amount)
            embed.color = discord.Color.red()
            embed.add_field(name="Result", value=f"💔 **LOSS!** -{bet_amount:,} FrostedCash", inline=False)
            embed.add_field(name="Odds", value="80% chance to lose - House always wins! 🎲", inline=False)

        embed.add_field(name="New Balance", value=f"**{new_balance:,} FrostedCash**", inline=False)
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Gambling(bot))