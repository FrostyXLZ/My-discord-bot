from discord.ext import commands
import discord
import random

class Fun(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.cold_jokes = [
            "Why don't penguins like online shopping? They're afraid of the phishing sites!",
            "What do snowmen eat for breakfast? Frosted Flakes!",
            "What do you call a snowman with a six-pack? An abdominal snowman!",
            "What do you get when you cross a snowman with a vampire? Frostbite!",
            "Why did the snowman go to the doctor? Because he had a cold!",
            "What do you call a bear with no teeth? A gummy bear in the snow!",
            "What kind of math do Snowy Owls like? Owlgebra!",
            "Why don't mountains get cold in the winter? They wear snowcaps!",
            "What do you call a cold dog? A chili dog!",
            "Why did the ice cream truck break down? It had a Rocky Road!",
            "Why did the scarecrow win an award? Because he was outstanding in his field!",
            "What did one ocean say to the other ocean? Nothing, they just waved!",
            "Why did the computer go to the doctor? It had a virus!"
        ]

    @commands.command(name='coldjoke')
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def cold_joke(self, ctx):
        """Get a random cold-themed joke!"""
        joke = random.choice(self.cold_jokes)
        
        embed = discord.Embed(
            title="❄️ Cold Joke Time! ❄️",
            description=(
                "```\n"
                f"**{joke}**\n"
                "```"
            ),
            color=discord.Color.blue()
        )
        embed.set_footer(text="┗━━━━━━ Stay frosty! ━━━━━━┛")
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Fun(bot))
