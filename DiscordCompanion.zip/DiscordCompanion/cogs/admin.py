from discord.ext import commands
import discord
from utils.storage import banned_users_storage
from utils.checks import is_owner

class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='terminate')
    @is_owner()
    async def terminate(self, ctx, user_id: str):
        """Ban a user from using the bot (Owner only)"""
        banned_users_storage.set(user_id, True)
        
        try:
            user = await self.bot.fetch_user(int(user_id))
            username = user.name if user else f"User {user_id}"
        except:
            username = f"User {user_id}"

        embed = discord.Embed(
            title="🚫 User Terminated",
            description=f"**{username}** has been banned from using the bot.",
            color=discord.Color.red()
        )
        await ctx.send(embed=embed)

    @commands.command(name='release')
    @is_owner()
    async def release(self, ctx, user_id: str):
        """Unban a user from the bot (Owner only)"""
        if user_id in banned_users_storage:
            banned_users_storage.set(user_id, False)
            
            try:
                user = await self.bot.fetch_user(int(user_id))
                username = user.name if user else f"User {user_id}"
            except:
                username = f"User {user_id}"

            embed = discord.Embed(
                title="✅ User Released",
                description=f"**{username}** has been unbanned from using the bot.",
                color=discord.Color.green()
            )
        else:
            embed = discord.Embed(
                title="❌ Error",
                description="This user was not terminated.",
                color=discord.Color.red()
            )
        await ctx.send(embed=embed)

    async def is_user_terminated(self, user_id: str) -> bool:
        """Check if a user is terminated"""
        return banned_users_storage.get(user_id, False)

async def setup(bot):
    admin_cog = Admin(bot)
    await bot.add_cog(admin_cog)
    
    # Add check for terminated users to all commands
    @bot.check
    async def check_not_terminated(ctx):
        if not ctx.command:
            return True
        
        # Allow owner to use commands regardless of termination
        if await ctx.bot.is_owner(ctx.author):
            return True
            
        # Check if user is terminated
        user_id = str(ctx.author.id)
        if await admin_cog.is_user_terminated(user_id):
            embed = discord.Embed(
                title="🚫 Access Denied",
                description="You have been terminated from using this bot.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return False
        return True
