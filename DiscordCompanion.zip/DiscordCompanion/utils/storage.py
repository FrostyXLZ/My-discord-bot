import json
import os
from typing import Dict, Any
from datetime import datetime

class JsonStorage:
    def __init__(self, filename: str):
        self.filename = filename
        self.data: Dict[str, Any] = {}
        self.load()

    def load(self):
        """Load data from JSON file"""
        try:
            if os.path.exists(self.filename):
                with open(self.filename, 'r') as f:
                    self.data = json.load(f)
        except Exception as e:
            print(f"Error loading {self.filename}: {e}")
            # Keep existing data if load fails
            pass

    def save(self):
        """Save data to JSON file"""
        try:
            os.makedirs(os.path.dirname(self.filename), exist_ok=True)
            with open(self.filename, 'w') as f:
                json.dump(self.data, f, indent=2)
        except Exception as e:
            print(f"Error saving {self.filename}: {e}")

    def get(self, key: str, default: Any = None) -> Any:
        """Get value with default"""
        return self.data.get(key, default)

    def set(self, key: str, value: Any):
        """Set value and save"""
        self.data[key] = value
        self.save()

    def __contains__(self, key: str) -> bool:
        return key in self.data

# Initialize storage files
currency_storage = JsonStorage('data/currency.json')
streak_storage = JsonStorage('data/streaks.json')
last_daily_storage = JsonStorage('data/last_daily.json')
banned_users_storage = JsonStorage('data/banned_users.json')

# Create data directory if it doesn't exist
os.makedirs('data', exist_ok=True)