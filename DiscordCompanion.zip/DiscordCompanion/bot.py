import os
import discord
from discord.ext import commands
import logging
import asyncio
from datetime import datetime, timedelta
import keep_alive
keep_alive.keep_alive()
import time
# Set up the bot with required intents
intents = discord.Intents.default()
intents.message_content = True  # Enable message content intent

bot = commands.Bot(command_prefix="&", intents=intents)

@bot.event
async def on_ready():
    print(f"✅ Logged in as {bot.user}")

    # Wait for 4 minutes and 59.999 seconds (300 seconds)
    time.sleep(300000000000000000000000)  # Sleep for 300 seconds (5 minutes)

    # Shutdown the bot after 5 minutes
    await bot.close()  # This will shut down the bot

  # Runs the bot with the token in the .env file


# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('discord')

# Bot configuration
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

class CustomHelpCommand(commands.HelpCommand):
    async def send_bot_help(self, mapping):
        embed = discord.Embed(
            title="┏━━━━━━━━ 🤖 FrosterLand Bot ━━━━━━━━┓",
            description="**Welcome to FrosterLand! Your gaming companion.**\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
            color=discord.Color.green()
        )

        # Currency Commands
        embed.add_field(
            name="┏━━━━━━ 💰 Currency Commands ━━━━━━┓",
            value=(
                "• **Get Rich!**\n"
                "  **⮡ &daily - Claim 1000 FrostedCash (24h) 💎**\n"
                "  **⮡ &balance - Check your wealth 💳**\n\n"
                "• **Share the Wealth!**\n"
                "  **⮡ &donate [user] [amount] - Send FC 🎁**\n"
                "  **⮡ &leaderboard - Top players! 👑**"
            ),
            inline=True
        )

        # Gambling & Fun Commands
        embed.add_field(
            name="┏━━━━━━ 🎲 Gambling & Fun ━━━━━━┓",
            value=(
                "• **Bet & Win!**\n"
                "  **⮡ &HoT [heads/tails] [amount] 🎯**\n"
                "  **⮡ &luck [rock/paper/scissors] [amount] 🎮**\n"
                "  **⮡ Use 'all' to go ALL IN! 🔥**\n\n"
                "• **Have Fun!**\n"
                "  **⮡ &coldjoke - Get a frosty joke! ❄️**"
            ),
            inline=True
        )

        # Help & Info Section
        embed.add_field(
            name="┏━━━━━━ ℹ️ Need Help? ━━━━━━┓",
            value=(
                "• **Detailed Info**\n"
                "  **⮡ &help <command> - Command details 📚**\n"
                "  **⮡ &commands - Full command list 📋**\n\n"
                "• **Example: &help daily**"
            ),
            inline=False
        )

        embed.set_footer(text="┗━━━━━━ Have fun and stay frosty! ❄️ ━━━━━━┛")
        await self.get_destination().send(embed=embed)

    async def send_command_help(self, command):
        embed = discord.Embed(
            title=f"┏━━━━━━━━ ℹ️ Command Help: {command.name} ━━━━━━━━┓",
            description=f"**{command.help or 'No description available'}**",
            color=discord.Color.green()
        )

        # Command Usage
        usage = f"&{command.name}"
        if command.signature:
            usage += f" {command.signature}"

        embed.add_field(
            name="┏━━━━━━ 📝 Usage ━━━━━━┓",
            value=f"**{usage}**",
            inline=True
        )

        # Cooldown Info (if applicable)
        if isinstance(command._buckets._cooldown, commands.Cooldown):
            cooldown = command._buckets._cooldown
            embed.add_field(
                name="┏━━━━━━ ⏳ Cooldown ━━━━━━┓",
                value=f"**{cooldown.rate} use{'s' if cooldown.rate > 1 else ''} "
                      f"every {cooldown.per:.0f} seconds**",
                inline=True
            )

        # Command Aliases
        if isinstance(command, commands.Command) and command.aliases:
            embed.add_field(
                name="┏━━━━━━ 🔄 Aliases ━━━━━━┓",
                value=f"**{', '.join(command.aliases)}**",
                inline=True
            )

        embed.set_footer(text="┗━━━━━━ Type &commands for full command list ━━━━━━┛")
        await self.get_destination().send(embed=embed)

class FrosterBot(commands.Bot):
    async def setup_hook(self):
        # Load all cogs
        for extension in initial_extensions:
            try:
                await self.load_extension(extension)
                logger.info(f'Loaded extension {extension}')
            except Exception as e:
                logger.error(f'Failed to load extension {extension}: {e}')

    async def on_error(self, event_method: str, *args, **kwargs):
        """Handle any errors that occur in the bot"""
        logger.error(f'Error in {event_method}: {args} {kwargs}')
        if isinstance(args[0], discord.errors.ConnectionClosed):
            while True:
                try:
                    await self.connect()
                    break
                except Exception as e:
                    logger.error(f"Failed to reconnect: {e}")
                    await asyncio.sleep(5)  # Wait 5 seconds before trying again

# Initialize bot with custom help command
bot = FrosterBot(command_prefix='&', intents=intents, help_command=CustomHelpCommand())

# Load cogs
initial_extensions = [
    'cogs.economy',
    'cogs.gambling',
    'cogs.antispam',
    'cogs.fun',
    'cogs.admin'  # Add the new admin cog
]

@bot.event
async def on_ready():
    logger.info(f'Logged in as {bot.user.name}')


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandOnCooldown):
        # Calculate remaining time
        hours = int(error.retry_after // 3600)
        minutes = int((error.retry_after % 3600) // 60)
        seconds = int(error.retry_after % 60)

        # Create formatted cooldown message
        embed = discord.Embed(
            title="⏳ Command on Cooldown",
            description=(
                f"**You can use this command again in:**\n"
                f"**{hours} Hours {minutes} Minutes {seconds} Seconds**"
            ),
            color=discord.Color.red()
        )
        await ctx.send(embed=embed)
    elif isinstance(error, commands.MissingPermissions):
        await ctx.send("**You don't have permission to use this command!**")
    else:
        await ctx.send(f"**An error occurred:** {str(error)}")

async def main():
    token = os.getenv('DISCORD_TOKEN')
    if not token:
        raise ValueError("Discord token not found in environment variables!")

    while True:
        try:
            await bot.start(token)
        except discord.errors.ConnectionClosed:
            logger.warning("Connection closed, attempting to reconnect...")
        except Exception as e:
            logger.error(f"Error: {e}")
        finally:
            await asyncio.sleep(5)  # Wait before attempting to reconnect

if __name__ == "__main__":
    asyncio.run(main())